"""Dotty: editable millimetre CAD. Run with Python 3.12 + cad/requirements.txt.

The puck is modeled face-up; +Y is the USB side. The separate stand tilts
the face 30 degrees above the table. All exported print STLs are bed-aligned.
Hardware stack height/USB height are prototype allowances, not measured fits.
"""
import json
import math
from pathlib import Path

import cadquery as cq

HERE = Path(__file__).resolve().parent
P = json.loads((HERE / "parameters.json").read_text())
OUT = HERE / "exports"


def ring(outer, inner, height, z=0):
    return cq.Workplane("XY", origin=(0, 0, z)).circle(outer / 2).circle(inner / 2).extrude(height)


def build():
    p = P
    od = p["outer_diameter"]
    bore = p["hardware_diameter"] + 2 * p["radial_clearance"]
    h = p["pcb_seat_height"] + p["display_stack_allowance"]
    lid_h = p["bezel_thickness"]
    assert 0 < p["stand_angle_degrees"] < 70
    assert p["view_diameter"] > 32.9  # Manufacturer's visible area.
    assert p["seat_inner_diameter"] < p["hardware_diameter"] < bore
    assert p["floor_thickness"] < p["usb_center_height"] - p["usb_height"] / 2
    bolt_radius = p["screw_circle_diameter"] / 2
    bolts = [(bolt_radius * math.cos(math.radians(a)),
              bolt_radius * math.sin(math.radians(a))) for a in (-90, 30, 150)]

    body = cq.Workplane("XY").circle(od / 2).extrude(h)
    body = body.edges(">Z").chamfer(0.6).edges("<Z").chamfer(0.6)
    body = body.cut(cq.Workplane("XY", origin=(0, 0, p["floor_thickness"]))
                    .circle(bore / 2).extrude(h + 1))
    # Three support tabs under the PCB's mounting-hole regions, with the XIAO
    # USB rotated to +Y. Avoid a continuous ledge that could hit the edge JST.
    # Their sloped undersides print without support; tops touch PCB, not glass.
    seat_z = p["pcb_seat_height"]
    tab = (cq.Workplane("XZ")
           .polyline([(bore / 2 + 0.1, seat_z - p["seat_thickness"]),
                      (bore / 2 + 0.8, seat_z - p["seat_thickness"]),
                      (bore / 2 + 0.8, seat_z),
                      (p["seat_inner_diameter"] / 2, seat_z)])
           .close().extrude(2.4, both=True))
    for a in (0, 143, 217):
        body = body.union(tab.rotate((0, 0, 0), (0, 0, 1), a))
    # Broad rear opening admits an ordinary cable overmold to the recessed USB.
    usb = cq.Workplane("XY").box(p["usb_width"], od, p["usb_height"],
                                 centered=(True, False, True))
    body = body.cut(usb.translate((0, 0, p["usb_center_height"])))
    # Blind pilots accept three M2 x 8 mm screws, gently hand-threaded in plastic.
    body = body.cut(cq.Workplane("XY", origin=(0, 0, h - 7.2)).pushPoints(bolts)
                    .circle(p["screw_pilot_diameter"] / 2).extrude(7.3))

    bezel = ring(od, p["view_diameter"], lid_h)
    bezel = bezel.edges(">Z").chamfer(0.5)
    bezel = bezel.cut(cq.Workplane("XY").pushPoints(bolts)
                      .circle(p["screw_clearance_diameter"] / 2).extrude(lid_h + 1))
    bezel = bezel.cut(cq.Workplane("XY", origin=(0, 0, lid_h - 1.4))
                      .pushPoints(bolts).circle(p["screw_head_diameter"] / 2).extrude(1.5))
    # Face down for printing: largest cosmetic face on the bed, no wide overhang.
    bezel_print = bezel.rotate((0, 0, 0), (1, 0, 0), 180).translate((0, 0, lid_h))

    # Circular wedge: flat table contact, tilted seating plane, shallow retaining
    # rim. A rear channel clears the USB cable; foam tape secures the loose fit.
    angle = p["stand_angle_degrees"]
    rad = math.radians(angle)
    seat_r = od / 2 + p["stand_radial_clearance"]
    stand_r = seat_r + 2.4
    center_z = p["stand_minimum_height"] + stand_r * math.tan(rad)
    axis = (1, 0, 0)

    def tilt(shape):
        return shape.rotate((0, 0, 0), axis, angle).translate((0, 0, center_z))

    stock = cq.Workplane("XY").circle(stand_r).extrude(center_z + stand_r + 10)
    # Half-space above the plane; the stock below it forms the wedge.
    upper = tilt(cq.Workplane("XY").box(200, 200, 150, centered=(True, True, False)))
    stand = stock.cut(upper)
    lip = tilt(ring((seat_r + 2.4) * 2, seat_r * 2, p["stand_lip_height"]))
    stand = stand.union(lip)
    # Cut past both the vertical base and tilted rim at the rear.
    channel = cq.Workplane("XY").box(p["usb_width"] + 2, 45, 100,
                                     centered=(True, False, False)).translate((0, 12, -1))
    stand = stand.cut(channel)

    fit_ring = ring(od, bore, 3.2)
    test_tab = (cq.Workplane("XY").box(bore / 2 + 0.8 - p["seat_inner_diameter"] / 2,
                 4.8, 1.0, centered=(False, True, False))
                .translate((p["seat_inner_diameter"] / 2, 0, 0)))
    for a in (0, 143, 217):
        fit_ring = fit_ring.union(test_tab.rotate((0, 0, 0), (0, 0, 1), a))
    # Mark the cable side with a small notch in the cheap test part.
    fit_ring = fit_ring.cut(cq.Workplane("XY").box(8, 15, 5,
                           centered=(True, False, False)).translate((0, 20, 0)))
    return {
        "body": body, "bezel": bezel_print, "stand-30deg": stand, "fit-ring": fit_ring
    }, {"body_height": h, "puck_height": h + lid_h,
        "stand_center_height": center_z, "stand_angle": angle,
        "stand_outer_diameter": stand_r * 2, "bezel_assembly": bezel}


def export():
    OUT.mkdir(exist_ok=True)
    parts, meta = build()
    report = {}
    for name, part in parts.items():
        shape = part.val()
        assert shape.isValid() and len(part.solids().vals()) == 1, name
        cq.exporters.export(part, str(OUT / f"{name}.stl"),
                            tolerance=0.05, angularTolerance=0.08)
        cq.exporters.export(part, str(OUT / f"{name}.step"))
        bb = shape.BoundingBox()
        report[name] = {"valid_solid": True, "solid_count": 1,
                        "size_mm": [round(bb.xlen, 3), round(bb.ylen, 3), round(bb.zlen, 3)],
                        "volume_mm3": round(shape.Volume(), 1)}
    assembly = cq.Assembly(name="Dotty")
    for name, part in parts.items():
        if name in ("fit-ring", "bezel"):
            continue
        if name == "body":
            part = part.rotate((0, 0, 0), (1, 0, 0), meta["stand_angle"])
            part = part.translate((0, 0, meta["stand_center_height"]))
        assembly.add(part, name=name)
    lid = meta["bezel_assembly"].translate((0, 0, meta["body_height"]))
    lid = lid.rotate((0, 0, 0), (1, 0, 0), meta["stand_angle"])
    lid = lid.translate((0, 0, meta["stand_center_height"]))
    assembly.add(lid, name="bezel")
    assembly.export(str(OUT / "assembly.step"))
    (OUT / "validation.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    export()
