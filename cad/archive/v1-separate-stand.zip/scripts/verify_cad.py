"""Verify the printable meshes and check that the assembled parts do not collide."""
import json
import sys
from pathlib import Path

import trimesh

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "cad"))
from enclosure import build

parts, meta = build()
checks = {}
for name in parts:
    mesh = trimesh.load_mesh(ROOT / "cad/exports" / f"{name}.stl")
    assert mesh.is_watertight, f"{name}: open mesh"
    assert mesh.is_winding_consistent and mesh.volume > 0, f"{name}: inverted faces"
    assert len(mesh.split()) == 1, f"{name}: disconnected pieces"
    assert abs(mesh.bounds[0, 2]) < 0.001, f"{name}: not on print bed"
    checks[name] = {"watertight": True, "connected_components": 1,
                    "triangles": len(mesh.faces), "bed_aligned": True}

tilted_body = parts["body"].rotate((0, 0, 0), (1, 0, 0), meta["stand_angle"])
tilted_body = tilted_body.translate((0, 0, meta["stand_center_height"]))
collision = tilted_body.intersect(parts["stand-30deg"]).val().Volume()
assert collision < 0.001, f"Stand intrudes into puck by {collision} mm³"
lid = meta["bezel_assembly"].translate((0, 0, meta["body_height"]))
overlap = lid.intersect(parts["body"]).val().Volume()
assert overlap < 0.001, f"Bezel intrudes into body by {overlap} mm³"
checks["assembly"] = {"body_stand_collision_mm3": round(collision, 6),
                       "body_bezel_collision_mm3": round(overlap, 6),
                       "face_angle_above_table_degrees": meta["stand_angle"]}
(ROOT / "cad/exports/mesh-checks.json").write_text(json.dumps(checks, indent=2) + "\n")
print(json.dumps(checks, indent=2))
