# Dotty

A small desktop puck for **Seeed Studio XIAO ESP32-C6 + Round Display for XIAO**, with a flat bottom sliced directly into the puck, so its screen sits **30 degrees above a horizontal desk**. The angle is built into the shell, and the extended rear is cropped to a flat vertical face for a puck-partly-buried-in-sand silhouette.

![CAD render; electronics and UI are illustrative](docs/enclosure-preview.png)

The project includes printable STL files, editable STEP solids and parametric Python CAD, plus a compiled Arduino starter showing **Hello, world!**, a **+1** touch counter, and a **Color** button. No Wi-Fi credentials, extra buttons, or LVGL configuration are needed.

**Prototype status:** the firmware compiles for the exact board and the meshes pass geometry checks. Physical fit, cable clearance, and touch behavior still need checking on your hardware. Print the small fit ring first. This version assumes USB power and standard pin headers; it does not allocate a battery compartment.

## Print first

Open these in your slicer at **100% scale, millimeters**:

| File | Purpose | Print orientation |
| --- | --- | --- |
| [fit-ring.stl](cad/exports/fit-ring.stl) | Quick diameter and support-position check | Already on bed |
| [body.stl](cad/exports/body.stl) | Puck shell, PCB supports, rear USB opening | Closed floor on bed |
| [bezel.stl](cad/exports/bezel.stl) | Removable front retaining ring | Already face down |

The complete print set is in [dotty-print-kit.zip](dotty-print-kit.zip).

Suggested starting settings: PLA or PETG, 0.4 mm nozzle, 0.2 mm layers, 3 walls, 4 top/bottom layers, 15-20% infill. Print the body on its broad flat bottom and the bezel face down. Inspect the USB roof and the internal PCB tabs for overhangs; use removable supports there if your slicer calls for them. Internal supports must be allowed to start on the printed floor. Use a brim only if bed adhesion needs it.

The circular face is **54 mm diameter**, with a **9.4 mm front rim and 36.4 mm rear rim**. The flat base is an angled slice through the round body, and a vertical slice removes the extended rear. The overall footprint is approximately **54 x 54.3 mm**, about **12 mm shorter** than the previous sliced-base version. The rear wall is 2 mm thick with an open USB notch; the circular display face stays intact. Maximum height remains about 38% lower than the original puck-plus-stand design. You also need **3 x M2 x 8 mm pan/socket-head screws** with heads no larger than 4.4 mm in diameter (heads up to 1.1 mm tall sit flush; taller heads can sit proud), a few small pieces of soft insulating foam tape, and optional rubber feet. The screws form threads in the 1.7 mm plastic pilot holes; gently hand-thread them before installing the electronics.

## Fit and assemble

1. Print the fit ring. Orient the assembled hardware with its XIAO USB connector toward the ring's notch. The 43 mm assembly should lower into the 44 mm bore without force. The three tabs should meet bare PCB around the mounting-hole areas, with no pressure on connectors, components, or the display flex cable. Stop and adjust the CAD if a tab conflicts with your revision.
2. Test the firmware while the hardware is outside the enclosure. The display board's power switch must be ON. Seat the XIAO in the display's 2 x 7 headers with USB facing outward, following Seeed's orientation.
3. Dry-fit the body. Rotate the USB toward the USB notch in the flat rear face. Check that the normal USB cable can fully insert without the case loading the connector. The notch is deliberately generous because header and cable heights vary. The model leaves about 0.7 mm between the assumed XIAO/header envelope and the inside of the new rear wall; check your actual assembly before tightening the bezel.
4. Add small, thin insulating foam pads to the PCB support tabs. Lower the assembly onto them. The **4.8 mm space between the support plane and bezel underside is an initial allowance**, based on the published 3.4 mm display module plus PCB and adhesive. Verify the actual stack before tightening anything. Add thin pads only at the black outer glass perimeter if there is free play; never compress the active screen or preload the glass.
5. Place the bezel and install the three screws finger-snug. The front opening is 38.8 mm, larger than the published 32.9 mm viewing area, so it covers only the outer black border. If the bezel cannot sit flush without pressing the display, increase `display_stack_allowance` and regenerate.
6. Set the sliced base directly on the desk and add thin rubber feet if wanted. The flat bottom provides the 30-degree viewing angle. No cradle or attachment tape is required.

Remove the bezel to reach the power switch, microSD slot, reset and boot buttons. The rendered electronics are illustrative; the printed enclosure has no integrated electrical buttons.

![Flat rear and USB notch](docs/rear-preview.png)

![Exploded assembly render](docs/exploded-preview.png)

## Run the display demo

The simplest route is Arduino IDE 2, which is already installed on this Mac:

1. In Boards Manager, install **esp32 by Espressif Systems**, version **3.3.12** (the version used for the build check). If needed, add `https://espressif.github.io/arduino-esp32/package_esp32_index.json` in Preferences under Additional Boards Manager URLs.
2. Install [Seeed_GFX](https://github.com/Seeed-Studio/Seeed_GFX) using Sketch > Include Library > Add .ZIP Library. The tested revision is `0dfdd7135425be82b5bb4b4b58d74dd51ab29a59` (2.0.3); a project-local copy is downloaded by the setup command below. This is Seeed's fork, whose header is still called `TFT_eSPI.h`. If a separate TFT_eSPI installation wins library selection, remove or move that conflicting library first. Seeed now also offers GFX2; this starter deliberately pins the working GFX API used in its Round Display guide.
3. Open [firmware/DottyHello/DottyHello.ino](firmware/DottyHello/DottyHello.ino). Keep `driver.h` next to it; it selects Seeed's Round Display profile 501.
4. Select **XIAO_ESP32C6**, the connected USB port, and **USB CDC On Boot: Enabled**. Upload using a USB data cable.
5. Tap **+1** to increase the count or **Color** to cycle through three accent colors. Holding a finger down counts once. The count resets when power is removed. Serial Monitor at 115200 prints touch positions; send `r` to reset the counter.

If the screen is rotated relative to the enclosure, change `kRotation` in the sketch to 1, 2, or 3. Rendering and touch coordinates rotate together. A full-screen sprite prevents redraw flicker; allocation failure falls back to direct drawing.

### Command line

These scripts keep the toolchain and downloaded display library **inside this project**, separate from Arduino IDE's libraries:

```sh
bash scripts/firmware.sh setup       # Downloads the pinned core and graphics library
bash scripts/firmware.sh build
bash scripts/firmware.sh ports
bash scripts/firmware.sh upload /dev/cu.usbmodemYOUR_PORT
bash scripts/firmware.sh monitor /dev/cu.usbmodemYOUR_PORT
```

The setup download is substantial because Espressif packages toolchains for several chips. Both `arduino-cli` on PATH and the CLI bundled with macOS Arduino IDE are supported. No upload was performed during project creation.

For a blank screen: confirm the display switch is ON, the 14 pins are correctly seated, the exact board is selected, and the compiler uses Seeed_GFX. For upload recovery, hold BOOT while connecting USB, then release BOOT and retry. For touch issues, look for the controller diagnostic in Serial Monitor and check seating; touch uses I2C address `0x2e` with interrupt D7.

## Change the enclosure

[cad/parameters.json](cad/parameters.json) contains dimensions in millimeters. `display_stack_allowance`, `usb_depth_below_face`, and `radial_clearance` are the main fit adjustments. `face_angle_degrees` sets the angle between screen and desk, while `face_center_height` controls how much material is sliced off the bottom. Reducing that height lowers both rims but also reduces hardware clearance. Local z=0 is the body/bezel joint, and the PCB underside is at `-display_stack_allowance`. The code checks an assumed 18 x 22 x 14 mm XIAO/header envelope centered toward the taller USB side, plus the display and a central underside-component allowance. Compare these assumptions to your assembled hardware before lowering the body further. `rear_flat_y` positions the flat back in desk coordinates (positive Y is rear), and `rear_wall_thickness` reserves solid material behind the cavity. Moving the flat back farther forward also reduces clearance to the XIAO. The USB opening is intentionally an open notch at the cropped wall.

```sh
python3.12 -m venv .venv
.venv/bin/pip install -r cad/requirements.txt
.venv/bin/python cad/enclosure.py
.venv/bin/python scripts/verify_cad.py
```

The exporter writes each part as STL and STEP, plus [assembly.step](cad/exports/assembly.step). The STEP assembly places the bezel directly on the sliced body. The body STL is in its desk/print orientation; the bezel STL is face down for printing. Keep `outer_diameter` large enough for the screw circle and the 4.4 mm screw heads. The support tab locations are based on this display's PCB, not a generic round board.

Optional preview regeneration, using Pillow and Blender:

```sh
.venv/bin/python scripts/make_display_preview.py
'/Applications/Blender.app/Contents/MacOS/Blender' -b --python scripts/render_preview.py
```

## Checks and references

- The exact-board Arduino compile passes: **345,454 bytes flash (26%), 16,204 bytes static RAM (4%)**. The 115,200-byte sprite is allocated at runtime and is additional to static RAM. Firmware has not been flashed or hardware tested.
- Each STL is checked for a single connected, watertight, consistently oriented positive-volume mesh and print-bed alignment. CAD checks also require valid solids, a broad horizontal base, no body/bezel interference, a solid flat rear wall around the USB notch, clearance from the assumed hardware envelopes and rear wall, and screw tips above the base. See [validation.json](cad/exports/validation.json) and [mesh-checks.json](cad/exports/mesh-checks.json). These checks do not prove physical hardware fit.
- [Seeed Round Display getting started](https://wiki.seeedstudio.com/get_start_round_display/) supplies the library setup, power-switch guidance, and official mechanical resources. The overview mentions a 39 mm disc, while its linked mechanical drawing specifies a **43.00 +/- 0.05 mm touch cover** and **3.40 +/- 0.15 mm module thickness**. This design follows the mechanical drawing and PCB outline.
- [Official display mechanical drawing](https://files.seeedstudio.com/wiki/round_display_for_xiao/GJX0128A4-15HY_Datasheet.pdf), drawing GJX0128A4-15HY, dated 2023-02-24. The PCB's outer arc gives a 21.5 mm radius. Its three mounting-hole coordinates are used to locate support tabs after rotating USB to the rear.
- [Official PCB source](https://files.seeedstudio.com/wiki/round_display_for_xiao/SeeedStudio_Round_Display_for_XIAO_v1.0_SCH%26PCB_230308.zip), v1.0, 2023-03-08. Check fit on later hardware revisions.
- [XIAO ESP32-C6 setup](https://wiki.seeedstudio.com/xiao_esp32c6_getting_started/) and [tested Seeed_GFX revision](https://github.com/Seeed-Studio/Seeed_GFX/tree/0dfdd7135425be82b5bb4b4b58d74dd51ab29a59).

Earlier designs are preserved in [v1-separate-stand.zip](cad/archive/v1-separate-stand.zip) and [v2-sliced-base.zip](cad/archive/v2-sliced-base.zip).

Next useful additions: a clock screen using the display's onboard RTC, Wi-Fi status, and a small settings view.
