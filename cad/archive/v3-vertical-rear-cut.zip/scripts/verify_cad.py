"""Check printable meshes, sliced base, inclined joint, and hardware allowances."""
import json
import sys
from pathlib import Path

import trimesh

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "cad"))
from enclosure import P, build

parts, meta = build()
checks = {}
for name in parts:
    mesh = trimesh.load_mesh(ROOT / "cad/exports" / f"{name}.stl")
    assert mesh.is_watertight, f"{name}: open mesh"
    assert mesh.is_winding_consistent and mesh.volume > 0, f"{name}: inverted faces"
    assert len(mesh.split()) == 1, f"{name}: disconnected pieces"
    assert abs(mesh.bounds[0, 2]) < 0.001, f"{name}: not on print bed"
    checks[name] = {"watertight": True, "connected_components": 1,
                    "triangles": len(mesh.faces), "bed_aligned": True}

body = parts["body"]
lid = meta["bezel_assembly"]
overlap = lid.intersect(body).val().Volume()
assert overlap < 0.001, f"Bezel intrudes into body by {overlap} mm³"
hardware_checks = {}
for name, volume in meta["hardware_envelopes"].items():
    collision = volume.intersect(body).val().Volume()
    assert collision < 0.001, f"Body intrudes into assumed {name}: {collision} mm³"
    lid_collision = volume.intersect(lid).val().Volume()
    assert lid_collision < 0.001, f"Bezel intrudes into assumed {name}: {lid_collision} mm³"
    bb = volume.val().BoundingBox()
    assert bb.zmin > P["floor_thickness"], f"{name} reaches the floor"
    assert bb.ymax < meta["rear_inner_y"], f"Rear wall truncates {name}"
    hardware_checks[name] = {"collision_mm3": round(collision, 6),
                             "minimum_floor_clearance_mm": round(bb.zmin - P["floor_thickness"], 3),
                             "minimum_rear_wall_clearance_mm": round(meta["rear_inner_y"] - bb.ymax, 3)}
    screw_collision = volume.intersect(meta["screw_envelope"]).val().Volume()
    assert screw_collision < 0.001, f"Screws intersect {name}"
assert meta["screw_envelope"].val().BoundingBox().zmin > 0, "Screw protrudes through base"
# A finite, horizontal contact face must exist, rather than point contact.
flat_faces = [f for f in body.faces().vals() if f.geomType() == "PLANE"
              and abs(f.Center().z) < 0.001 and abs(f.normalAt().z) > 0.999]
assert flat_faces and sum(f.Area() for f in flat_faces) > 1500, "No broad flat base"
rear_faces = [f for f in body.faces().vals() if f.geomType() == "PLANE"
              and abs(f.Center().y - meta["rear_flat_y"]) < 0.001 and abs(f.normalAt().y) > 0.999]
assert rear_faces and sum(f.Area() for f in rear_faces) > 150, "Missing closed flat rear wall"
assert body.val().BoundingBox().ymax < meta["rear_flat_y"] + 0.05, "Rear wasn't fully cropped"
checks["assembly"] = {"body_bezel_collision_mm3": round(overlap, 6),
                       "face_angle_above_table_degrees": meta["face_angle"],
                       "front_top_height_mm": round(meta["front_top_height"], 2),
                       "rear_top_height_mm": round(meta["rear_top_height"], 2),
                       "flat_base_contact_area_mm2": round(sum(f.Area() for f in flat_faces), 1),
                       "rear_flat_y_mm": meta["rear_flat_y"],
                       "rear_flat_wall_area_mm2": round(sum(f.Area() for f in rear_faces), 1),
                       "assumed_hardware_clearance": hardware_checks,
                       "separate_stand": False}
(ROOT / "cad/exports/mesh-checks.json").write_text(json.dumps(checks, indent=2) + "\n")
print(json.dumps(checks, indent=2))
